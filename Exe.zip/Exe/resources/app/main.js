const { BrowserWindow } = require("electron");

function createWindow(){
    const window = new BrowserWindow({
        width: 900,
        height: 750,
        autoHideMenuBar:true,
        icon: "public/img/favicon.ico",
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: true,
        }
    });
   window.loadFile("./public/index.html");
}
module.exports = {
    createWindow,
}